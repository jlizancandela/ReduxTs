import { setData } from "../slices/pokemonSlice";
import { AppDispatch } from "../store";

import { pokemonInstance } from "../../apis/pokemonApi";

export const getPokemons = () => {
  return async (dispach: AppDispatch) => {
    const { data } = await pokemonInstance.get("/pokemon?limit=151");
    dispach(setData(data.results));
  };
};
