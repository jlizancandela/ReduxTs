import { createSlice, PayloadAction } from "@reduxjs/toolkit";

// Define el tipo de estado
export interface PokemonsState {
  data: object[];
}

// Estado inicial
const initialState: PokemonsState = {
  data: [],
};

// Define el slice con tipos explícitos
const pokemonsSlice = createSlice({
  name: "pokemons",
  initialState,
  reducers: {
    setData: (state, action: PayloadAction<object[]>) => {
      state.data = action.payload;
    },
  },
});

// Exporta las acciones y el reducer
export const { setData } = pokemonsSlice.actions;
export default pokemonsSlice.reducer;
