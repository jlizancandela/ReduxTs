import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import "./App.css";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "./store/store";
import {
  increment,
  incrementByAmount,
  decrement,
  reset as resetCounter,
} from "./store/slices/counterSlice";

import { useInput } from "./hooks/useInput";

function App() {
  const count = useSelector((state: RootState) => state.counter.value);
  const dispatch = useDispatch();
  const { values, onChange, reset } = useInput({ number: "" });

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const numberValue = Number(values.number);
    if (!isNaN(numberValue)) {
      dispatch(incrementByAmount(numberValue));
    }
    reset();
  };

  return (
    <>
      <div>
        <a href="https://vitejs.dev" target="_blank">
          <img src={viteLogo} className="logo" alt="Vite logo" />
        </a>
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
      </div>
      <h1>Vite + React</h1>
      <div className="card">
        <div
          style={{
            display: "flex",
            gap: "10px",
            flexDirection: "row",
            justifyContent: "center",
          }}
        >
          <button onClick={() => dispatch(increment())}>
            count is {count}
          </button>
          <button onClick={() => dispatch(decrement())}>-</button>
          <button onClick={() => dispatch(resetCounter())}>reset</button>
        </div>
        <div style={{ marginTop: "20px" }}>
          <form
            onSubmit={onSubmit}
            style={{ display: "flex", gap: "10px", flexDirection: "column" }}
          >
            <input
              type="number"
              name="number"
              onChange={onChange}
              value={values.number}
              placeholder="Enter number"
              style={{
                width: "300px",
                padding: "10px",
                borderRadius: "10px",
                justifyContent: "center",
                marginLeft: "auto",
                marginRight: "auto",
              }}
            />
            <button
              type="submit"
              style={{
                width: "300px",
                marginLeft: "auto",
                marginRight: "auto",
              }}
            >
              Submit
            </button>
          </form>
        </div>
        <p>
          Edit <code>src/App.tsx</code> and save to test HMR
        </p>
      </div>
      <p className="read-the-docs">
        Click on the Vite and React logos to learn more
      </p>
    </>
  );
}

export default App;
